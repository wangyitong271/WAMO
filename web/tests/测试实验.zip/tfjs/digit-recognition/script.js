const canvas = document.getElementById("main-canvas");
const smallCanvas = document.getElementById("small-canvas");
const displayBox = document.getElementById("prediction");
const confidence = document.getElementById("confidence");

const inputBox = canvas.getContext("2d");
const smBox = smallCanvas.getContext("2d");

let isDrawing = false;
let model;
// 存储内存分析结果
let memoryAnalysisData = {
    addressRanges: [],
    uniqueAddresses: new Set()
};

/* Loads trained model */
async function init() {
    model = await tf.loadModel("model/model.json");
}

function drawStartEvent(event) {
    isDrawing = true;

    inputBox.strokeStyle = "white";
    inputBox.lineWidth = "15";
    inputBox.lineJoin = inputBox.lineCap = "round";
    inputBox.beginPath();
}
canvas.addEventListener("mousedown", drawStartEvent);
canvas.addEventListener("ontouchstart", drawStartEvent);

function drawMoveEvent(event) {
    if (isDrawing) {
        drawStroke(event.clientX, event.clientY);
    }
}
canvas.addEventListener("mousemove", drawMoveEvent);
canvas.addEventListener("ontouchmove", drawMoveEvent);

function drawEndEvent(event) {
    isDrawing = false;
    updateDisplay(predict());
}
canvas.addEventListener("mouseup", drawEndEvent);
canvas.addEventListener("ontouchend", drawEndEvent);

/* Draws on canvas */
function drawStroke(clientX, clientY) {
    // get mouse coordinates on canvas
    const rect = canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    // draw
    inputBox.lineTo(x, y);
    inputBox.stroke();
    inputBox.moveTo(x, y);
}

/* Makes predictions */
function predict() {
    // 跟踪每个阶段的内存状态
    const memInitial = tf.memory();
    console.log("初始内存状态:", memInitial);
    memoryAnalysisData.addressRanges.push(memInitial.numBytes);
    
    // 获取输入数据
    let values = getPixelData();
    const memAfterGetData = tf.memory();
    console.log("获取数据后内存状态:", memAfterGetData);
      // 记录预测前的内存状态
    const memBefore = tf.memory();
    console.log("内存状态（预测前）:", memBefore);
    memoryAnalysisData.addressRanges.push(memBefore.numBytes);
    
    // 注意: tf.profile 在 0.12.0 版本中不可用
    // 我们改为手动记录内存变化
    console.log("开始模型推理...");
    
    // 执行预测
    let predictions;
      // 正常执行预测
    predictions = model.predict(values);
    
    // 记录每一层的信息 (简化版本)
    try {
        // 获取模型的所有层
        if (model.layers) {
            console.log(`模型共有 ${model.layers.length} 层`);
            
            // 仅记录层的信息，而不创建新的模型或获取输出
            model.layers.forEach((layer, index) => {
                try {
                    const layerInfo = {
                        name: layer.name,
                        type: layer.constructor.name,
                        outputShape: layer.outputShape
                    };
                    console.log(`层 ${index} 信息:`, layerInfo);
                    
                    // 记录每层的唯一标识符
                    if (layer.id) {
                        memoryAnalysisData.addressRanges.push(layer.id);
                        memoryAnalysisData.uniqueAddresses.add(`layer-${layer.name}-${layer.id}`);
                    }
                } catch (e) {
                    console.log(`无法获取层 ${index} 的信息:`, e);
                }
            });
        }
    } catch (e) {
        console.log("获取层信息时出错:", e);
    }
    
    // 分析推理过程中的内存访问
    analyzeMemoryAccess(predictions);
    
    // 获取预测结果
    let predData = predictions.dataSync();
    
    // 记录预测后的内存状态
    const memAfter = tf.memory();
    console.log("内存状态（预测后）:", memAfter);
    memoryAnalysisData.addressRanges.push(memAfter.numBytes);
    
    // 记录内存变化
    const memoryChange = memAfter.numBytes - memBefore.numBytes;
    console.log(`内存变化: ${memoryChange} 字节`);
    
    // 分析内存使用情况
    const analysisResults = getMemoryAnalysisResults();
    console.log("内存访问分析结果:", analysisResults);
    
    // 释放中间tensor
    predictions.dispose();
    values.dispose();
    
    // 执行垃圾回收
    tf.tidy(() => {});
    
    return predData;
}

/* Returns pixel data from canvas after applying transformations */
function getPixelData() {
    smBox.drawImage(
        inputBox.canvas,
        0,
        0,
        smallCanvas.width,
        smallCanvas.height
    );
    const imgData = smBox.getImageData(
        0,
        0,
        smallCanvas.width,
        smallCanvas.height
    );

    // preserve and normalize values from red channel only
    let values = [];
    for (let i = 0; i < imgData.data.length; i += 4) {
        values.push(imgData.data[i] / 255);
    }
    values = tf.reshape(values, [1, 28, 28, 1]);
    return values;
}

/* Displays predictions on screen */
function updateDisplay(predictions) {
    // Find index of best prediction, which corresponds to the predicted value
    const maxValue = Math.max(...predictions);
    const bestPred = predictions.indexOf(maxValue);
    confidence.innerHTML = `<strong>${Math.round(maxValue * 100)}%</strong> confidence`;
    displayBox.innerText = bestPred;
    
    // 更新内存分析结果显示
    updateMemoryAnalysisDisplay();
}

/* 更新内存分析结果显示 */
function updateMemoryAnalysisDisplay() {
    const results = getMemoryAnalysisResults();
    const memoryInfo = tf.memory();
    
    // 更新基本分析结果
    document.getElementById('address-span').innerText = results.addressSpan.toLocaleString();
    document.getElementById('unique-address-count').innerText = results.uniqueAddressCount;
    document.getElementById('memory-utilization').innerText = 
        (results.memoryUtilizationRatio * 100).toFixed(2) + '%';
    
    // 更新额外内存信息
    document.getElementById('total-memory').innerText = memoryInfo.numBytes.toLocaleString();
    document.getElementById('tensor-count').innerText = memoryInfo.numTensors;
    
    // 生成详细内存报告
    const detailsText = generateMemoryDetailsReport(memoryInfo, results);
    document.getElementById('memory-details-text').innerText = detailsText;
}

/* 生成详细内存报告 */
function generateMemoryDetailsReport(memoryInfo, analysisResults) {
    // 创建详细报告
    let report = `--- 内存访问详细分析 ---\n\n`;
    
    // TensorFlow.js 内存信息
    report += `TensorFlow.js 内存状态:\n`;
    report += `- 总内存: ${(memoryInfo.numBytes || 0).toLocaleString()} bytes\n`;
    report += `- 未释放张量: ${memoryInfo.numTensors || '未知'}\n`;
    report += `- 版本: TensorFlow.js 0.12.0\n\n`;
    
    // 内存访问分析
    report += `内存访问分析:\n`;
    report += `- 内存地址跨度: ${(analysisResults.addressSpan || 0).toLocaleString()}\n`;
    report += `- 唯一内存地址数: ${analysisResults.uniqueAddressCount || 0}\n`;
    
    // 防止除以零或者NaN
    const utilizationRatio = isFinite(analysisResults.memoryUtilizationRatio) ? 
        analysisResults.memoryUtilizationRatio : 0;
    report += `- 内存利用率: ${(utilizationRatio * 100).toFixed(2)}%\n\n`;
    
    // 地址范围分布
    report += `地址范围分布:\n`;
    if (memoryAnalysisData.addressRanges && memoryAnalysisData.addressRanges.length > 0) {
        // 过滤非数值和无效值
        const validRanges = memoryAnalysisData.addressRanges
            .filter(val => val !== undefined && val !== null && !isNaN(Number(val)));
            
        if (validRanges.length > 0) {
            const sortedRanges = [...validRanges].sort((a, b) => Number(a) - Number(b));
            report += `- 最小值: ${(sortedRanges[0] || 0).toLocaleString()}\n`;
            report += `- 最大值: ${(sortedRanges[sortedRanges.length-1] || 0).toLocaleString()}\n`;
            
            // 计算均值和中位数
            if (sortedRanges.length > 1) {
                try {
                    const sum = sortedRanges.reduce((a, b) => Number(a) + Number(b), 0);
                    const avg = sum / sortedRanges.length;
                    
                    const midIdx = Math.floor(sortedRanges.length/2);
                    const median = sortedRanges.length % 2 === 0 ? 
                        (Number(sortedRanges[midIdx]) + Number(sortedRanges[midIdx - 1])) / 2 :
                        Number(sortedRanges[midIdx]);
                        
                    report += `- 平均值: ${isFinite(avg) ? avg.toLocaleString() : 'N/A'}\n`;
                    report += `- 中位数: ${isFinite(median) ? median.toLocaleString() : 'N/A'}\n`;
                } catch (e) {
                    report += `- 计算统计数据时出错\n`;
                }
            }
        } else {
            report += `- 暂无有效数据\n`;
        }
    } else {
        report += `- 暂无数据\n`;
    }
    
    // 添加一些调试信息
    report += `\n调试信息:\n`;
    report += `- 唯一地址项: ${Array.from(memoryAnalysisData.uniqueAddresses).slice(0, 5).join(', ')}${memoryAnalysisData.uniqueAddresses.size > 5 ? '...' : ''}\n`;
    report += `- 推理完成时间: ${new Date().toLocaleTimeString()}\n`;
    
    return report;
}

document.getElementById("erase").addEventListener("click", erase);

/* 分析内存访问情况 */
function analyzeMemoryAccess(tensor) {
    try {
        // 尝试获取tensor的唯一标识（如果可能）
        if (tensor) {
            // 尝试获取tensor的shape和其他可能有用的信息
            const shape = tensor.shape;
            const size = tensor.size;
            const dtype = tensor.dtype;
            
            console.log("Tensor信息:", { shape, size, dtype });
            
            // 使用tensor的一些特征作为地址的代理
            const tensorId = `tensor-${shape}-${size}-${Date.now() % 10000}`;
            memoryAnalysisData.addressRanges.push(size);
            memoryAnalysisData.uniqueAddresses.add(tensorId);
            
            // 尝试同步获取数据
            try {
                const data = tensor.dataSync();
                // 使用数据的哈希作为另一个地址的代理
                const dataHash = data.reduce((a, b) => a + b, 0);
                memoryAnalysisData.addressRanges.push(dataHash);
            } catch (e) {
                console.log("无法同步获取tensor数据:", e);
            }
        }

        // 使用tf.tidy来获取并释放一个临时tensor，这将触发TF.js内部的内存管理
        tf.tidy(() => {
            // 尝试获取一些关于TF.js内存的信息
            const engineState = tf.ENV.engine;
            if (engineState) {
                // 记录关于引擎的一些可能有用的信息
                console.log("TF.js引擎:", engineState);
                
                // 对于0.12.0版本，尝试获取可能存在的内部引擎状态
                const numDataIds = engineState.numDataIds;
                if (numDataIds !== undefined) {
                    memoryAnalysisData.addressRanges.push(numDataIds);
                    memoryAnalysisData.uniqueAddresses.add(`engine-dataIds-${numDataIds}`);
                }
            }
            
            // 创建一个临时tensor并返回，会被tidy自动清理
            return tf.tensor([1, 2, 3]);
        });
        
        // 获取内存信息
        const memoryInfo = tf.memory();
        console.log("内存信息:", memoryInfo);
        
        // 记录内存使用量
        if (memoryInfo.numBytes !== undefined) {
            memoryAnalysisData.addressRanges.push(memoryInfo.numBytes);
        }
        
        // 记录张量数量
        if (memoryInfo.numTensors !== undefined) {
            memoryAnalysisData.uniqueAddresses.add(`tensors-count-${memoryInfo.numTensors}`);
        }
        
        return tensor;
    } catch (e) {
        console.error("内存访问分析错误:", e);
        return null;
    }
}

/* 获取内存分析结果 */
function getMemoryAnalysisResults() {
    // 计算内存地址跨度
    let maxAddrValue = -Infinity;
    let minAddrValue = Infinity;
    let validValues = 0;
    
    // 检查是否有有效数据
    if (!memoryAnalysisData.addressRanges || memoryAnalysisData.addressRanges.length === 0) {
        return {
            addressSpan: 0,
            uniqueAddressCount: memoryAnalysisData.uniqueAddresses ? memoryAnalysisData.uniqueAddresses.size : 0,
            memoryUtilizationRatio: 0
        };
    }
    
    // 处理每个地址值
    memoryAnalysisData.addressRanges.forEach(addr => {
        try {
            // 安全地将各种类型的地址表示转换为数值
            let addrValue;
            
            if (addr === undefined || addr === null) {
                return; // 跳过无效值
            }
            
            if (typeof addr === 'object') {
                // 对象情况，使用其字符串表示的长度作为代理值
                try {
                    addrValue = JSON.stringify(addr).length;
                } catch (e) {
                    // 如果无法序列化，使用对象的属性数量
                    addrValue = Object.keys(addr).length;
                }
            } else if (typeof addr === 'number') {
                // 数字情况，直接使用
                addrValue = addr;
            } else if (typeof addr === 'string') {
                // 字符串情况，尝试转换为数字，如果失败则使用字符串长度
                const parsed = parseFloat(addr);
                addrValue = !isNaN(parsed) ? parsed : addr.length;
            } else {
                // 其他情况，尝试转换为字符串再获取长度
                addrValue = String(addr).length;
            }
            
            // 确保我们有一个有效的数字
            if (!isNaN(addrValue) && isFinite(addrValue)) {
                maxAddrValue = Math.max(maxAddrValue, addrValue);
                minAddrValue = Math.min(minAddrValue, addrValue);
                validValues++;
            }
        } catch (e) {
            console.error("处理地址值时出错:", e);
        }
    });
    
    // 如果没有有效值，返回默认值
    if (validValues === 0 || maxAddrValue === -Infinity || minAddrValue === Infinity) {
        return {
            addressSpan: 0,
            uniqueAddressCount: memoryAnalysisData.uniqueAddresses ? memoryAnalysisData.uniqueAddresses.size : 0,
            memoryUtilizationRatio: 0
        };
    }
    
    const addressSpan = maxAddrValue - minAddrValue;
    const uniqueAddressCount = memoryAnalysisData.uniqueAddresses ? memoryAnalysisData.uniqueAddresses.size : 0;
    
    return {
        // 内存访问地址跨度
        addressSpan: addressSpan,
        // 唯一内存地址访问数量
        uniqueAddressCount: uniqueAddressCount,
        // 内存利用率：唯一地址数量/跨度 (防止除以零)
        memoryUtilizationRatio: addressSpan > 0 ? uniqueAddressCount / addressSpan : 0
    };
}

/* Clears canvas */
function erase() {
    inputBox.fillStyle = "#111";
    inputBox.fillRect(0, 0, canvas.width, canvas.height);
    displayBox.innerText = "";
    confidence.innerHTML = "&#8212";
    
    // 重置内存分析数据
    memoryAnalysisData = {
        addressRanges: [],
        uniqueAddresses: new Set()
    };
}

erase();
init();
